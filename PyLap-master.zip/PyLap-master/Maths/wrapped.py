#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 07:54:48 2020

@author: william
"""

def nrlmsiseoo():
    pass
def irreg_strength():
    pass
def iri2016():
    pass
def iri2012():
    pass
def iri2007():
    pass
