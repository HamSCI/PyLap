#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 07:32:42 2020

@author: william
"""
import test_im_a
def test_im(arg):
    a = test_im_a.test_im_a(arg)
    print(a)