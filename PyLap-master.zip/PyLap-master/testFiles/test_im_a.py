#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 07:34:21 2020

@author: william
"""

def test_im_a(arg):
    print(arg)
    return arg