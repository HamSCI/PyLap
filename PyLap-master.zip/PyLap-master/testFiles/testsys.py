#!/usr/bin/env python3
import sys
#def testsys():
print('here for test')
sys.exit('testsys')


